package interfaces;

public interface AreaMeasurable {
    public double getArea();
}
